import "./App.css";
declare function App(): import("react/jsx-runtime").JSX.Element;
export default App;
